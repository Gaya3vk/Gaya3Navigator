var data = [
{
    "ProductId": 1,
    "ProductName": "Apple I-Pad Mini",
    "ImageURL": "images/Apple/01.jpg",
    "Price": 25699,
},
{
    "ProductId": 2,
    "ProductName": "Apple I-Phone 4s",
    "Price": 28900,
    "ImageURL": "images/Apple/02.jpg"
},
{
    "ProductId": 3,
    "ProductName": "Apple I-Phone 5s",
    "Price": 38269,
    "ImageURL": "images/Apple/03.jpg"
},
  
{
    "ProductId": 7,
    "ProductName": "Motorola Gen 3",
    "Price": 12499,
    "ImageURL": "images/Moto/07.jpg",
    "CompanyId": 1008,
    "CompanyName": "MOTO",
    "CategoryId": 2002,
    "CategoryName": "Android"
  },
  {
    "ProductId": 8,
    "ProductName": "Motorola X",
    "Price": 18499,
    "ImageURL": "images/Moto/08.jpg",
    "CompanyId": 1008,
    "CompanyName": "MOTO",
    "CategoryId": 2002,
    "CategoryName": "Android"
  },
  {
    "ProductId": 9,
    "ProductName": "BlackBerry Classic",
    "Price": 30500,
    "ImageURL": "images/BB/09.jpg",
    "CompanyId": 1002,
    "CompanyName": "BLACKBERRY",
    "CategoryId": 2004,
    "CategoryName": "BlackBerry"
  },
  {
    "ProductId": 10,
    "ProductName": "BlackBerry Leap",
    "Price": 21325,
    "ImageURL": "images/BB/10.jpg",
    "CompanyId": 1002,
    "CompanyName": "BLACKBERRY",
    "CategoryId": 2004,
    "CategoryName": "BlackBerry"
  },
  {
    "ProductId": 11,
    "ProductName": "BlackBerry Passport",
    "Price": 39999,
    "ImageURL": "images/BB/11.jpg",
    "CompanyId": 1002,
    "CompanyName": "BLACKBERRY",
    "CategoryId": 2004,
    "CategoryName": "BlackBerry"
  },
  {
    "ProductId": 12,
    "ProductName": "Nokia Lumia 735",
    "Price": 7499,
    "ImageURL": "images/Nokia/12.jpg",
    "CompanyId": 1009,
    "CompanyName": "NOKIA",
    "CategoryId": 2003,
    "CategoryName": "Windows"
  },
  {
    "ProductId": 13,
    "ProductName": "Nokia Lumia 930",
    "Price": 18499,
    "ImageURL": "images/Nokia/13.jpg",
    "CompanyId": 1009,
    "CompanyName": "NOKIA",
    "CategoryId": 2003,
    "CategoryName": "Windows"
  },
  {
    "ProductId": 14,
    "ProductName": "Nokia X1",
    "Price": 18490,
    "ImageURL": "images/Nokia/14.jpg",
    "CompanyId": 1009,
    "CompanyName": "NOKIA",
    "CategoryId": 2003,
    "CategoryName": "Windows"
  },
  {
    "ProductId": 15,
    "ProductName": "Nokia X Plus",
    "Price": 4980,
    "ImageURL": "images/Nokia/15.jpg",
    "CompanyId": 1009,
    "CompanyName": "NOKIA",
    "CategoryId": 2003,
    "CategoryName": "Windows"
  },
  {
    "ProductId": 16,
    "ProductName": "Sandisk Sdcard",
    "Price": 298,
    "ImageURL": "images/accs/14.jpg",
    "CompanyId": 1007,
    "CompanyName": "SAMSUNG",
    "CategoryId": 2002,
    "CategoryName": "Android"
  },
  {
    "ProductId": 17,
    "ProductName": "Samsung Ear Phone",
    "Price": 200,
    "ImageURL": "images/accs/13.jpg",
    "CompanyId": 1007,
    "CompanyName": "SAMSUNG",
    "CategoryId": 2002,
    "CategoryName": "Android"
  },
  {
    "ProductId": 18,
    "ProductName": "I-Phone 6S case",
    "Price": 1500,
    "ImageURL": "images/accs/8.jpg",
    "CompanyId": 1007,
    "CompanyName": "APPLE",
    "CategoryId": 2002,
    "CategoryName": "I-Phone"
  },
  {
    "ProductId": 19,
    "ProductName": "Sony PowerBank",
    "Price":999,
    "ImageURL": "images/accs/7.jpg",
    "CompanyId": 1007,
    "CompanyName": "SONY",
    "CategoryId": 2002,
    "CategoryName": "Android"
  },
  {
    "ProductId": 20,
    "ProductName": "ASUS Zenphone case",
    "Price": 130,
    "ImageURL": "images/accs/4.jpg",
    "CompanyId": 1007,
    "CompanyName": "ASUS",
    "CategoryId": 2002,
    "CategoryName": "Android"
  },
  {
    "ProductId": 21,
    "ProductName": "Gionee Charger",
    "Price": 500,
    "ImageURL": "images/accs/12.jpg",
    "CompanyId": 1007,
    "CompanyName": "Gionee",
    "CategoryId": 2002,
    "CategoryName": "Android"
  },
];


var str;
function displayProducts(){
	for(var i=0; i<data.length;i++){

str = '<div class="col-md-4 col-sm-6 col-xs-12 product">';
            str += '<div class="widthei"><figure><img src="' +data[i].ImageURL + '" />';
            str += '<figcaption>' + data[i].ProductName + '</figcaption></figure>';
            str += '<div class="price">' + data[i].Price + '</div>';
            str += '<div class="addtocart">';
            str += '<button class="btn btn-primary btnCart" id='+i+' " onclick = "getClicked(this.id)" >Add to cart</button>';
            str += '</div></div></div>';
            document.getElementById('demo').innerHTML+=str;

}
console.log(str);
}
window.load=displayProducts();


var count=1;
var mod;
var total=0;
var price=0;
const tax=0.02;
var taxamount;
var totalamount;
var discount;
var qty;
var inc=[];
const offr=50000;
const threshold=150000;
function getClicked(id){
    var details = id;
    /*console.log(data[details].ProductName);
    console.log(data[details].Price);
    console.log(data[details].ImageURL);
    */
            mod = '<div class="col-md-4 col-sm-6 col-xs-12 products">';
            mod += '<div class="images"><figure><img src="' +data[details].ImageURL + '" />';
            mod += '<figcaption>' + data[details].ProductName + '</figcaption></figure>';
            mod += '<div class="price2">' + data[details].Price + '</div>';
            mod += '</div></div>';
            document.getElementById('addproducts').innerHTML+=mod;
            document.getElementById("cart").innerHTML = count++;
            price=data[details].Price;
            inc=data[details].ProductId;
            console.log(inc);
            total = total+price;
            taxamount=total*tax;
            totalamount=total+taxamount;
            document.getElementById("totalprice").innerHTML=total;
            document.getElementById("totaltax").innerHTML=taxamount;
            document.getElementById("totalamount").innerHTML=totalamount;
                if(total>offr){
                    discount=offr*10/100;
                    total=total-discount;
                    taxamount=total*tax;
                    totalamount=total+taxamount;
                    document.getElementById("discount").innerHTML=total;
                    document.getElementById("totaltax").innerHTML=taxamount;
                    document.getElementById("totalamount").innerHTML=totalamount;
               }
               if(totalamount>threshold){
                alert("You are exceeding the limit");
               }
              
}



    


